import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Button,
  Card,
  Descriptions,
  Modal,
  Space,
  Table,
  Tag,
  Typography,
  message,
  Input,
} from "antd";
import { approveGrn, cancelGrn, getGrn, type GrnDetail } from "./purchaseApi";
import { ReloadOutlined } from "@ant-design/icons";

const { Title, Text } = Typography;

export default function GrnDetailPage() {
  const nav = useNavigate();
  const { id } = useParams();
  const grnId = Number(id);

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<GrnDetail | null>(null);

  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [acting, setActing] = useState(false);

  async function load() {
    try {
      setLoading(true);
      const r = await getGrn(grnId);
      setData(r);
    } catch (e: any) {
      message.error(e?.response?.data?.message || "โหลด GRN ไม่สำเร็จ", 2);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!Number.isFinite(grnId) || grnId <= 0) return;
    load();
  }, [grnId]);

  const header = data?.header;
  const items = data?.items ?? [];

  const total = useMemo(() => {
    return items.reduce((sum, it) => sum + Number(it.qty) * Number(it.unit_cost), 0);
  }, [items]);

  const canApprove = header?.status === "DRAFT";
  const canCancel = header?.status === "DRAFT" || header?.status === "APPROVED";

  async function onApprove() {
    Modal.confirm({
      title: "Approve GRN?",
      content: "เมื่ออนุมัติแล้ว ระบบจะเพิ่มสต็อก + สร้าง lot และ stock_moves",
      okText: "Approve",
      cancelText: "ยกเลิก",
      centered: true,
      async onOk() {
        try {
          setActing(true);
          await approveGrn(grnId);
          message.success("Approve สำเร็จ", 1.2);
          await load();
        } catch (e: any) {
          message.error(e?.response?.data?.message || "Approve ไม่สำเร็จ", 2);
        } finally {
          setActing(false);
        }
      },
    });
  }

  async function onCancel() {
    const reason = cancelReason.trim();
    if (reason.length < 5) {
      message.error("กรอกเหตุผลอย่างน้อย 5 ตัวอักษร", 2);
      return;
    }

    try {
      setActing(true);
      await cancelGrn(grnId, reason);
      message.success("ยกเลิก GRN แล้ว", 1.2);
      setCancelOpen(false);
      setCancelReason("");
      await load();
    } catch (e: any) {
      message.error(e?.response?.data?.message || "ยกเลิกไม่สำเร็จ", 2);
    } finally {
      setActing(false);
    }
  }

  const columns = [
    { title: "สินค้า", dataIndex: "name", key: "name", render: (_: any, r: any) => (
      <div className="leading-tight">
        <div className="font-medium">{r.name}</div>
        <div className="text-xs text-gray-500">{r.code}</div>
      </div>
    )},
    { title: "จำนวน", dataIndex: "qty", key: "qty", width: 140 },
    { title: "ต้นทุน/หน่วย", dataIndex: "unit_cost", key: "unit_cost", width: 160, render: (v: any) => Number(v).toLocaleString() },
    { title: "รวม", key: "total", width: 180, render: (_: any, r: any) => (Number(r.qty) * Number(r.unit_cost)).toLocaleString() },
  ];

  function statusTag(s?: string) {
    if (s === "APPROVED") return <Tag color="green">APPROVED</Tag>;
    if (s === "CANCELLED") return <Tag> CANCELED</Tag>;
    return <Tag color="gold">DRAFT</Tag>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <Title level={3} className="!mb-1">
            GRN Detail
          </Title>
          <Text type="secondary">ดูรายละเอียด + Approve/Cancel</Text>
        </div>

        <Space>
          <Button onClick={() => nav("/purchase/grn")}>กลับรายการ</Button>
          <Button type="primary" onClick={() => nav("/purchase/grn/new")}>สร้างใหม่</Button>
        </Space>
      </div>

      <Card loading={loading}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="text-lg font-semibold">{header?.grn_no || "-"}</div>
            {statusTag(header?.status)}
          </div>

          <Space>
            <Button icon={<ReloadOutlined />} onClick={load} loading={loading}>
              Refresh
            </Button>
            <Button type="primary" onClick={onApprove} disabled={!canApprove || acting}>
              Approve
            </Button>
            <Button danger onClick={() => setCancelOpen(true)} disabled={!canCancel || acting}>
              Cancel
            </Button>
          </Space>
        </div>

        <Descriptions className="mt-4" column={2} bordered size="small">
          <Descriptions.Item label="Issue date">{header?.issue_date || "-"}</Descriptions.Item>
          <Descriptions.Item label="Warehouse ID">{header?.warehouse_id ?? "-"}</Descriptions.Item>
          <Descriptions.Item label="Vendor ID">{header?.vendor_id ?? "-"}</Descriptions.Item>
          <Descriptions.Item label="Note">{header?.note || "-"}</Descriptions.Item>
          <Descriptions.Item label="Cancel reason" span={2}>{header?.cancel_reason || "-"}</Descriptions.Item>
        </Descriptions>
      </Card>

      <Card title="รายการสินค้า">
        <Table
          rowKey="id"
          columns={columns as any}
          dataSource={items}
          pagination={false}
        />
        <div className="flex justify-end mt-4">
          <div className="text-right">
            <div className="text-sm text-gray-500">รวมมูลค่า</div>
            <div className="text-lg font-semibold">{total.toLocaleString()}</div>
          </div>
        </div>
      </Card>

      <Modal
        open={cancelOpen}
        title="Cancel GRN"
        okText="ยืนยันยกเลิก"
        okButtonProps={{ danger: true, loading: acting }}
        onOk={onCancel}
        centered
        onCancel={() => {
          setCancelOpen(false);
          setCancelReason("");
        }}
      >
        <div className="mb-2 text-gray-600 text-sm">
          ถ้า GRN เป็น APPROVED ระบบจะ reverse stock ได้เฉพาะกรณี lot ยังไม่ถูกใช้ (qty_out=0)
        </div>
        <Input.TextArea
          rows={4}
          value={cancelReason}
          onChange={(e) => setCancelReason(e.target.value)}
          placeholder="เหตุผล (อย่างน้อย 5 ตัวอักษร)"
        />
      </Modal>
    </div>
  );
}
