import { useEffect, useMemo, useState } from "react";
import {
  Button,
  Card,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Select,
  Space,
  Table,
  Typography,
  message,
} from "antd";
import dayjs from "dayjs";
import { useLocation, useNavigate } from "react-router-dom";
import {
  createGrn,
  getPo,
  listProducts,
  listVendors,
  listWarehouses,
  type ProductRow,
  type VendorRow,
  type WarehouseRow,
} from "./purchaseApi";

const { Title, Text } = Typography;

type Line = {
  key: string;
  product_id?: number;
  qty?: number;
  unit_cost?: number;
};

function safeUUID() {
  // กันบาง environment ไม่มี crypto.randomUUID
  // @ts-ignore
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `k_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

export default function GrnCreatePage() {
  const nav = useNavigate();
  const location = useLocation();

  // ✅ รับ poId ได้ทั้ง query และ state
  const poIdFromQuery = useMemo(() => {
    const sp = new URLSearchParams(location.search);
    const n = Number(sp.get("poId") || 0);
    return Number.isFinite(n) && n > 0 ? n : null;
  }, [location.search]);

  const poIdFromState = useMemo(() => {
    const st: any = location.state;
    const n = Number(st?.po_id || 0);
    return Number.isFinite(n) && n > 0 ? n : null;
  }, [location.state]);

  const poId = poIdFromQuery ?? poIdFromState ?? null;

  const [loading, setLoading] = useState(false);

  const [products, setProducts] = useState<ProductRow[]>([]);
  const [vendors, setVendors] = useState<VendorRow[]>([]);
  const [warehouses, setWarehouses] = useState<WarehouseRow[]>([]);

  const [form] = Form.useForm();
  const [lines, setLines] = useState<Line[]>([{ key: safeUUID(), qty: 1, unit_cost: 0 }]);

  // ใช้เช็คว่าโหลด PO สำเร็จไหม (เอาไว้โชว์ subtitle)
  const [poNo, setPoNo] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);

        const [p, v, w] = await Promise.all([listProducts(), listVendors(), listWarehouses()]);
        setProducts(p.filter((x) => x.is_active === 1));
        setVendors(v.filter((x) => x.is_active === 1));
        setWarehouses(w.filter((x) => x.is_active === 1));

        // ค่าเริ่มต้น
        form.setFieldsValue({ issue_date: dayjs() });

        // ✅ ถ้ามาจาก PO: โหลด PO แล้วเติม form + lines
        if (poId) {
          const po = await getPo(poId);

          setPoNo(po?.header?.po_no || null);

          // เติม header -> form
          form.setFieldsValue({
            vendor_id: po.header.vendor_id,
            warehouse_id: po.header.warehouse_id,
            note: po.header.note ?? null,
            issue_date: dayjs(), // GRN รับเข้าวันนี้ (คุณจะเปลี่ยนเป็น po.header.issue_date ก็ได้)
          });

          // ตั้ง default grn_no ถ้ายังไม่ได้พิมพ์
          const currentGrnNo = form.getFieldValue("grn_no");
          if (!currentGrnNo) {
            // ตัวอย่าง: GRN-PO-2026-001 (หรือจะทำแบบอื่นก็ได้)
            form.setFieldsValue({ grn_no: `GRN-${po.header.po_no}` });
          }

          // เติม items -> lines
          const poItems = Array.isArray(po.items) ? po.items : [];
          if (poItems.length > 0) {
            setLines(
              poItems.map((it) => ({
                key: safeUUID(),
                product_id: Number(it.product_id),
                qty: Number(it.qty || 0),
                unit_cost: Number(it.unit_cost || 0),
              })),
            );
          } else {
            // ถ้า PO ไม่มี items ก็ยังคง 1 แถวว่างไว้
            setLines([{ key: safeUUID(), qty: 1, unit_cost: 0 }]);
          }
        }
      } catch (e: any) {
        message.error(e?.response?.data?.message || "โหลดข้อมูลไม่สำเร็จ", 2);
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [poId]);

  const totals = useMemo(() => {
    let qty = 0;
    let amount = 0;
    for (const l of lines) {
      const q = Number(l.qty || 0);
      const c = Number(l.unit_cost || 0);
      qty += q;
      amount += q * c;
    }
    return { qty, amount };
  }, [lines]);

  function addLine() {
    setLines((prev) => [...prev, { key: safeUUID(), qty: 1, unit_cost: 0 }]);
  }

  function removeLine(key: string) {
    setLines((prev) => prev.filter((x) => x.key !== key));
  }

  async function submit() {
    const v = await form.validateFields();

    const items = lines
      .filter((l) => l.product_id && l.qty && l.unit_cost !== undefined)
      .map((l) => ({
        product_id: Number(l.product_id),
        qty: Number(l.qty),
        unit_cost: Number(l.unit_cost),
      }))
      .filter((x) => x.product_id > 0 && x.qty > 0 && x.unit_cost >= 0);

    if (items.length === 0) {
      message.error("ต้องมีรายการสินค้าอย่างน้อย 1 รายการ", 2);
      return;
    }

    try {
      setLoading(true);
      const payload = {
        grn_no: String(v.grn_no).trim(),
        po_id: poId ?? null, // ✅ ส่ง po_id
        vendor_id: Number(v.vendor_id),
        warehouse_id: Number(v.warehouse_id),
        issue_date: dayjs(v.issue_date).format("YYYY-MM-DD"),
        note: v.note ? String(v.note) : null,
        items,
      };

      const r = await createGrn(payload);
      message.success("สร้าง GRN (DRAFT) แล้ว", 1.2);
      nav(`/purchase/grn/${r.id}`, { replace: true });
    } catch (e: any) {
      message.error(e?.response?.data?.message || "สร้าง GRN ไม่สำเร็จ", 2);
    } finally {
      setLoading(false);
    }
  }

  const lockByPo = !!poId; // ✅ ถ้ามาจาก PO ให้ล็อก Vendor/Warehouse ไม่ให้เปลี่ยน

  const columns = [
    {
      title: "สินค้า",
      dataIndex: "product_id",
      render: (_: any, row: Line) => (
        <Select
          showSearch
          placeholder="เลือกสินค้า"
          value={row.product_id}
          onChange={(val) => {
            setLines((prev) =>
              prev.map((x) => (x.key === row.key ? { ...x, product_id: val } : x)),
            );
          }}
          filterOption={(input, option) =>
            String(option?.label ?? "").toLowerCase().includes(input.toLowerCase())
          }
          options={products.map((p) => ({
            value: p.id,
            label: `${p.code} - ${p.name}`,
          }))}
          style={{ width: "100%" }}
        />
      ),
    },
    {
      title: "จำนวน",
      dataIndex: "qty",
      width: 140,
      render: (_: any, row: Line) => (
        <InputNumber
          min={1}
          value={row.qty}
          onChange={(val) => {
            setLines((prev) =>
              prev.map((x) => (x.key === row.key ? { ...x, qty: Number(val || 0) } : x)),
            );
          }}
          style={{ width: "100%" }}
        />
      ),
    },
    {
      title: "ต้นทุน/หน่วย",
      dataIndex: "unit_cost",
      width: 180,
      render: (_: any, row: Line) => (
        <InputNumber
          min={0}
          value={row.unit_cost}
          onChange={(val) => {
            setLines((prev) =>
              prev.map((x) =>
                x.key === row.key ? { ...x, unit_cost: Number(val ?? 0) } : x,
              ),
            );
          }}
          style={{ width: "100%" }}
        />
      ),
    },
    {
      title: "รวม",
      key: "line_total",
      width: 180,
      render: (_: any, row: Line) => {
        const q = Number(row.qty || 0);
        const c = Number(row.unit_cost || 0);
        return <span>{(q * c).toLocaleString()}</span>;
      },
    },
    {
      title: "",
      key: "actions",
      width: 90,
      render: (_: any, row: Line) => (
        <Button danger onClick={() => removeLine(row.key)} disabled={lines.length <= 1}>
          ลบ
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <Title level={3} className="!mb-1">
            สร้าง GRN
          </Title>
          <Text type="secondary">
            {poId
              ? `สร้างจาก PO: ${poNo ?? `#${poId}`} (ระบบจะดึงรายการสินค้าอัตโนมัติ)`
              : "สร้างใบรับเข้า (DRAFT) ก่อน แล้วค่อย Approve เพื่อให้สต็อกเข้า"}
          </Text>
        </div>

        <Space>
          <Button onClick={() => nav("/purchase/grn")}>กลับรายการ</Button>
          <Button type="primary" loading={loading} onClick={submit}>
            บันทึก (DRAFT)
          </Button>
        </Space>
      </div>

      <Card loading={loading}>
        <Form form={form} layout="vertical">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Form.Item
              name="grn_no"
              label="เลขที่ GRN"
              rules={[{ required: true, message: "กรอกเลขที่ GRN" }]}
            >
              <Input placeholder="เช่น GRN-2026-0001" />
            </Form.Item>

            <Form.Item
              name="issue_date"
              label="วันที่รับเข้า"
              rules={[{ required: true, message: "เลือกวันที่" }]}
            >
              <DatePicker className="w-full" />
            </Form.Item>

            <Form.Item
              name="vendor_id"
              label="Vendor"
              rules={[{ required: true, message: "เลือก Vendor" }]}
            >
              <Select
                showSearch
                placeholder="เลือกผู้ขาย"
                disabled={lockByPo}
                options={vendors.map((v) => ({ value: v.id, label: `${v.code} - ${v.name}` }))}
              />
            </Form.Item>

            <Form.Item
              name="warehouse_id"
              label="Warehouse"
              rules={[{ required: true, message: "เลือกคลัง" }]}
            >
              <Select
                showSearch
                placeholder="เลือกคลัง"
                disabled={lockByPo}
                options={warehouses.map((w) => ({ value: w.id, label: `${w.code} - ${w.name}` }))}
              />
            </Form.Item>
          </div>

          <Form.Item name="note" label="หมายเหตุ (ถ้ามี)">
            <Input.TextArea rows={2} />
          </Form.Item>
        </Form>
      </Card>

      <Card
        title="รายการสินค้า"
        extra={
          <Button onClick={addLine} disabled={false /* ถ้าต้องล็อกไม่ให้แก้จาก PO ก็ปรับตรงนี้ได้ */}>
            เพิ่มรายการ
          </Button>
        }
      >
        <Table rowKey="key" columns={columns as any} dataSource={lines} pagination={false} />

        <div className="flex justify-end mt-4">
          <div className="text-right">
            <div className="text-sm text-gray-500">รวมจำนวน</div>
            <div className="text-lg font-semibold">{totals.qty.toLocaleString()}</div>
            <div className="text-sm text-gray-500 mt-2">รวมมูลค่า</div>
            <div className="text-lg font-semibold">{totals.amount.toLocaleString()}</div>
          </div>
        </div>
      </Card>
    </div>
  );
}
