// purchaseApi.ts
import api from "../../lib/api";

// --------------------- MASTER LISTS ---------------------

export type ProductRow = {
  id: number;
  code: string;
  name: string;
  unit: string | null;
  sell_price: number;
  is_active: number;
};

export type WarehouseRow = {
  id: number;
  code: string;
  name: string;
  location: string | null;
  description: string | null;
  is_active: number;
};

/**
 * VendorRow (legacy) - ใช้แสดงใน dropdown PO
 * ถ้าคุณมี vendor master แบบใหม่ (vendor detail) ให้ใช้ getVendor() เพิ่ม
 */
export type VendorRow = {
  id: number;
  code: string;
  name: string;
  tax_id: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  is_active: number;
};

export type TaxType = "EXCLUDE_VAT_7" | "INCLUDE_VAT_7" | "NO_VAT";

export async function listProducts(): Promise<ProductRow[]> {
  const { data } = await api.get("/products");
  return Array.isArray(data) ? data : [];
}

export async function listWarehouses(): Promise<WarehouseRow[]> {
  const { data } = await api.get("/warehouses");
  return Array.isArray(data) ? data : [];
}

export async function listVendors(): Promise<VendorRow[]> {
  const { data } = await api.get("/vendors");
  return Array.isArray(data) ? data : [];
}

// --------------------- VENDOR DETAIL (for selecting primary contact) ---------------------

/**
 * ถ้า backend /vendors/:id คืนฟิลด์มากกว่านี้ คุณเพิ่มได้ตามจริง
 * (ผมทำให้ optional เพื่อไม่ให้พัง ถ้าบาง key ไม่มี)
 */
export type VendorContactPerson = {
  prefix?: string | null;
  first_name?: string | null;
  last_name?: string | null;
  nickname?: string | null;
  email?: string | null;
  phone?: string | null;
  position?: string | null;
};

export type VendorDetail = VendorRow & {
  contact_person?: VendorContactPerson;
  // ถ้าคุณมี list ผู้ติดต่อหลายคนใน backend จริง ๆ
  // คุณสามารถเปลี่ยนให้เป็น array ได้ แล้วใช้ในหน้า PO create
  contact_people?: VendorContactPerson[];
};

export async function getVendor(id: number): Promise<VendorDetail> {
  const { data } = await api.get(`/vendors/${id}`);
  return data as VendorDetail;
}

// --------------------- GRN ---------------------

export type GrnStatus = "DRAFT" | "APPROVED" | "CANCELLED";

export type GrnHeader = {
  id: number;
  company_id: number;
  grn_no: string;

  // ✅ รองรับ GRN จาก PO
  po_id?: number | null;

  vendor_id: number;
  warehouse_id: number;
  status: GrnStatus;
  issue_date: string;
  note: string | null;

  created_by: number;
  approved_by?: number | null;
  approved_at?: string | null;

  cancelled_by?: number | null;
  cancelled_at?: string | null;
  cancel_stage?: "DRAFT" | "APPROVED" | null;
  cancel_reason?: string | null;

  created_at?: string;
  updated_at?: string;
};

export type GrnItem = {
  id: number;
  product_id: number;
  code: string;
  name: string;
  qty: number;
  unit_cost: number;
};

export type GrnDetail = {
  header: GrnHeader;
  items: GrnItem[];
};

export type CreateGrnPayload = {
  grn_no: string;

  // ✅ ส่ง po_id ได้
  po_id?: number | null;

  vendor_id: number;
  warehouse_id: number;
  issue_date: string;
  note?: string | null;
  items: { product_id: number; qty: number; unit_cost: number }[];
};

export async function createGrn(payload: CreateGrnPayload): Promise<{ id: number }> {
  const { data } = await api.post("/purchase/grn", payload);
  return data;
}

export async function getGrn(id: number): Promise<GrnDetail> {
  const { data } = await api.get(`/purchase/grn/${id}`);
  return data;
}

export async function approveGrn(id: number) {
  const { data } = await api.post(`/purchase/grn/${id}/approve`);
  return data;
}

export async function cancelGrn(id: number, reason: string) {
  const { data } = await api.post(`/purchase/grn/${id}/cancel`, { reason });
  return data;
}

export type GrnListRow = {
  id: number;
  company_id: number;
  grn_no: string;
  status: GrnStatus;
  issue_date: string;
  created_at?: string;

  vendor_name: string;
  warehouse_name: string;

  item_count?: number;
  total_amount?: number;
};

export type GrnListResponse = {
  rows: GrnListRow[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};

export async function listGrn(params?: {
  q?: string;
  status?: "" | GrnStatus;
  page?: number;
  pageSize?: number;

  // ✅ เผื่อทำ sort GRN ด้วย
  sort_by?: string;
  sort_dir?: "asc" | "desc";
}): Promise<GrnListResponse> {
  const { data } = await api.get("/purchase/grn", { params });
  return data;
}

// --------------------- PO ---------------------

export type PoStatus = "DRAFT" | "APPROVED" | "CANCELLED";

export type PoVendorContactSnapshot = {
  name?: string | null;
  phone?: string | null;
  email?: string | null;
  position?: string | null;
};

export type PoHeader = {
  id: number;
  company_id: number;
  po_no: string;
  vendor_id: number;
  warehouse_id: number;
  status: PoStatus;
  issue_date: string;
  expected_date: string | null;
  note: string | null;

  created_by: number;
  approved_by: number | null;
  approved_at: string | null;

  cancelled_by: number | null;
  cancelled_at: string | null;
  cancel_reason: string | null;

  created_at?: string;
  updated_at?: string;

  // (optional - เผื่อ backend ส่ง join name มา)
  vendor_name?: string;
  warehouse_name?: string;

  // ✅ ใหม่: snapshot ผู้ติดต่อหลัก (แบบเดิมที่เคยคุยไว้)
  vendor_contact_name?: string | null;
  vendor_contact_phone?: string | null;
  vendor_contact_email?: string | null;
  vendor_contact_position?: string | null;

  // ✅ เพิ่ม: snapshot ผู้ติดต่อหลัก "ตาม backend purchase.service.js ที่คุณใช้อยู่จริง"
  vendor_person_prefix?: string | null;
  vendor_person_first_name?: string | null;
  vendor_person_last_name?: string | null;
  vendor_person_nickname?: string | null;
  vendor_person_email?: string | null;
  vendor_person_phone?: string | null;
  vendor_person_position?: string | null;
  vendor_person_department?: string | null;

  // เผื่อมี id
  vendor_person_id?: number | null;
};

export type PoItem = {
  id: number;
  product_id: number;
  code: string;
  name: string;
  qty: number;
  unit_cost: number;
  discount_pct?: number;
  discount_amt?: number;
  tax_type?: TaxType;
  line_net?: number;
};

export type PoDetail = {
  header: PoHeader;
  items: PoItem[];
};

export type CreatePoPayload = {
  // หมายเหตุ: ตอน AUTO คุณส่ง null/ไม่ส่ง po_no ก็ได้ (แล้วแต่ backend)
  po_no?: string | null;

  vendor_id: number;
  warehouse_id: number;
  issue_date: string;
  expected_date?: string | null;
  note?: string | null;

  // ✅ ใหม่: ผู้ติดต่อหลัก (optional)
  vendor_contact?: PoVendorContactSnapshot;

  // ✅ ใหม่: เผื่อส่ง vendor_person_id (ถ้า FE รองรับเลือกคน)
  vendor_person_id?: number | null;

  items: { product_id: number; qty: number; unit_cost: number }[];
};

export type PoListRow = {
  id: number;
  company_id: number;
  po_no: string;
  status: PoStatus;
  issue_date: string;
  expected_date?: string | null;

  vendor_name: string;
  warehouse_name: string;

  item_count?: number;
  total_amount?: number;

  created_at?: string;

  // ✅ ใหม่: เผื่ออยากโชว์ใน list ด้วย
  vendor_contact_name?: string | null;

  // ✅ เพิ่ม: เผื่อโชว์จาก snapshot แบบ vendor_person_*
  vendor_person_first_name?: string | null;
  vendor_person_last_name?: string | null;
  vendor_person_phone?: string | null;
  vendor_person_email?: string | null;
};

export type PoListResponse = {
  rows: PoListRow[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};

export async function listPo(params?: {
  q?: string;
  status?: "" | PoStatus;
  page?: number;
  pageSize?: number;

  // ✅ ใหม่: sort
  sort_by?: "po_no" | "vendor_name" | "status" | "issue_date" | "expected_date" | "total_amount";
  sort_dir?: "asc" | "desc";
}): Promise<PoListResponse> {
  const { data } = await api.get("/purchase/po", { params });
  return data;
}

export async function createPo(payload: CreatePoPayload): Promise<{ id: number; po_no?: string }> {
  const { data } = await api.post("/purchase/po", payload);
  return data;
}

export async function getPo(id: number): Promise<PoDetail> {
  const { data } = await api.get(`/purchase/po/${id}`);
  return data;
}

export async function approvePo(id: number) {
  const { data } = await api.post(`/purchase/po/${id}/approve`);
  return data;
}

export async function cancelPo(id: number, reason: string) {
  const { data } = await api.post(`/purchase/po/${id}/cancel`, { reason });
  return data;
}
