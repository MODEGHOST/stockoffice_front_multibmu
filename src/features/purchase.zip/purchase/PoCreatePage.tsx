// PoCreatePage.tsx
import { useEffect, useMemo, useState } from "react";
import {
  Button,
  Card,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Select,
  Space,
  Switch,
  Typography,
  message,
  Divider,
} from "antd";
import dayjs from "dayjs";
import { useNavigate } from "react-router-dom";
import api from "../../lib/api";
import {
  createPo,
  listProducts,
  listVendors,
  listWarehouses,
  type ProductRow,
  type VendorRow,
  type WarehouseRow,
} from "./purchaseApi";

const { Title, Text } = Typography;

type VendorPerson = {
  id: number;
  prefix?: string | null;
  first_name: string;
  last_name: string;
  nickname?: string | null;
  email?: string | null;
  phone?: string | null;
  position?: string | null;
  department?: string | null;
  is_primary?: number;
  sort_order?: number;
};

type VendorDetailForPeople = {
  id: number;
  code: string;
  name: string;
  people?: VendorPerson[];
};

type TaxType = "EXCLUDE_VAT_7" | "INCLUDE_VAT_7" | "NO_VAT";

type Line = {
  key: string;
  product_id?: number;
  onhand?: number;
  qty?: number;
  unit_cost?: number;

  discount_pct?: number;
  discount_amt?: number;
  tax_type?: TaxType;
};

function calcLine(l: Line) {
  const qty = Number(l.qty || 0);
  const unit = Number(l.unit_cost || 0);
  const base = qty * unit;

  const dp = Number(l.discount_pct || 0);
  const da = Number(l.discount_amt || 0);

  const discByPct = base * (dp / 100);
  const discount = Math.min(base, discByPct + da);
  const beforeTax = Math.max(0, base - discount);

  // PO เน้นยอดก่อนภาษี
  return { qty, base, discount, beforeTax, total: beforeTax };
}

function personLabel(p: VendorPerson) {
  const name = `${p.prefix ? `${p.prefix} ` : ""}${p.first_name} ${p.last_name}`.trim();
  const nick = p.nickname ? ` (${p.nickname})` : "";
  const pos = p.position ? ` • ${p.position}` : "";
  const dept = p.department ? ` • ${p.department}` : "";
  const phone = p.phone ? ` • ${p.phone}` : "";
  const email = p.email ? ` • ${p.email}` : "";
  const primary = Number(p.is_primary ?? 0) === 1 ? " (Primary)" : "";
  return `${name}${nick}${pos}${dept}${phone}${email}${primary}`.trim();
}

export default function PoCreatePage() {
  const nav = useNavigate();
  const [loading, setLoading] = useState(false);

  const [products, setProducts] = useState<ProductRow[]>([]);
  const [vendors, setVendors] = useState<VendorRow[]>([]);
  const [warehouses, setWarehouses] = useState<WarehouseRow[]>([]);

  const [form] = Form.useForm();

  const [lines, setLines] = useState<Line[]>([
    {
      key: crypto.randomUUID(),
      qty: 1,
      unit_cost: 0,
      tax_type: "EXCLUDE_VAT_7",
      discount_pct: 0,
      discount_amt: 0,
    },
  ]);

  // AUTO by default
  const [autoNo, setAutoNo] = useState(true);

  // vendor people
  const [vendorPeople, setVendorPeople] = useState<VendorPerson[]>([]);
  const [loadingPeople, setLoadingPeople] = useState(false);

  async function loadMaster() {
    try {
      setLoading(true);

      const [p, v, w] = await Promise.all([
        listProducts(),
        listVendors(),
        listWarehouses(),
      ]);

      setProducts(p.filter((x) => x.is_active === 1));
      setVendors(v.filter((x) => x.is_active === 1));
      setWarehouses(w.filter((x) => x.is_active === 1));

      form.setFieldsValue({
        issue_date: dayjs(),
        expected_date: null,
        po_no: "",
        vendor_id: undefined,
        vendor_person_id: undefined,
        warehouse_id: undefined,
        note: null,

        // ✅ ค่าใช้จ่ายเพิ่มเติม (header)
        extra_charge_amt: 0,
        extra_charge_note: null,
      });
    } catch (e: any) {
      message.error(e?.response?.data?.message || "โหลดข้อมูลไม่สำเร็จ", 2);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadMaster();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function normalizePoNo(v: any) {
    if (v === undefined || v === null) return null;
    const s = String(v).trim();
    if (!s || s.toLowerCase() === "undefined") return null;
    return s;
  }

  function addLine() {
    setLines((prev) => [
      ...prev,
      {
        key: crypto.randomUUID(),
        qty: 1,
        unit_cost: 0,
        tax_type: "EXCLUDE_VAT_7",
        discount_pct: 0,
        discount_amt: 0,
      },
    ]);
  }

  function removeLine(key: string) {
    setLines((prev) => prev.filter((x) => x.key !== key));
  }

  function setLine(key: string, patch: Partial<Line>) {
    setLines((prev) => prev.map((x) => (x.key === key ? { ...x, ...patch } : x)));
  }

  async function loadVendorPeople(vendorId: number) {
    setLoadingPeople(true);
    try {
      const { data } = await api.get(`/vendors/${vendorId}`);
      const vd = data as VendorDetailForPeople;

      const list = Array.isArray(vd?.people) ? vd.people : [];
      const sorted = [...list].sort((a, b) => {
        const ap = Number(a.is_primary ?? 0);
        const bp = Number(b.is_primary ?? 0);
        if (bp !== ap) return bp - ap;
        return Number(a.sort_order ?? 0) - Number(b.sort_order ?? 0);
      });

      setVendorPeople(sorted);

      const primary = sorted.find((p) => Number(p.is_primary ?? 0) === 1) || sorted[0];

      form.setFieldsValue({
        vendor_person_id: primary?.id ? Number(primary.id) : undefined,
      });
    } catch (e: any) {
      setVendorPeople([]);
      form.setFieldsValue({ vendor_person_id: undefined });
      message.error(e?.response?.data?.message || "โหลดผู้ติดต่อ Vendor ไม่สำเร็จ", 2);
    } finally {
      setLoadingPeople(false);
    }
  }

  // watch vendor_id -> โหลด vendor_people
  const vendorId = Form.useWatch("vendor_id", form) as number | undefined;

  useEffect(() => {
    if (!vendorId) {
      setVendorPeople([]);
      form.setFieldsValue({ vendor_person_id: undefined });
      return;
    }
    loadVendorPeople(Number(vendorId));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vendorId]);

  // ✅ watch ค่าใช้จ่ายเพิ่มเติมจาก form
  const extraChargeAmt = Form.useWatch("extra_charge_amt", form) as number | undefined;

  const summary = useMemo(() => {
    let totalQty = 0;
    let base = 0;
    let discount = 0;
    let net = 0;

    for (const l of lines) {
      const r = calcLine(l);
      totalQty += r.qty;
      base += r.base;
      discount += r.discount;
      net += r.total;
    }

    const extra = Number(extraChargeAmt ?? 0) || 0;

    return {
      lineCount: lines.length,
      totalQty,
      base,
      discount,
      net,
      extra,
      grandTotal: net + extra,
    };
  }, [lines, extraChargeAmt]);

  async function submit() {
    const v = await form.validateFields();

    const items = lines
      .map((l) => ({
        product_id: Number(l.product_id || 0),
        qty: Number(l.qty || 0),
        unit_cost: Number(l.unit_cost ?? 0),

        discount_pct: Number(l.discount_pct ?? 0),
        discount_amt: Number(l.discount_amt ?? 0),
        tax_type: l.tax_type ?? "EXCLUDE_VAT_7",
      }))
      .filter((x) => x.product_id > 0 && x.qty > 0 && x.unit_cost >= 0);

    if (items.length === 0) {
      message.error("ต้องมีรายการสินค้าอย่างน้อย 1 รายการ (เลือกสินค้า/จำนวน/ต้นทุน)", 2);
      return;
    }

    try {
      setLoading(true);

      const poNo = autoNo ? null : normalizePoNo(v.po_no);
      if (!autoNo && !poNo) {
        message.error("โหมด MANUAL ต้องกรอกเลขที่ PO", 2);
        return;
      }

      const payload: any = {
        vendor_id: Number(v.vendor_id),
        warehouse_id: Number(v.warehouse_id),
        issue_date: dayjs(v.issue_date).format("YYYY-MM-DD"),
        expected_date: v.expected_date ? dayjs(v.expected_date).format("YYYY-MM-DD") : null,
        note: v.note ? String(v.note) : null,
        items,

        vendor_person_id: v.vendor_person_id ? Number(v.vendor_person_id) : null,

        // ✅ ค่าใช้จ่ายเพิ่มเติม (header)
        extra_charge_amt: Number(v.extra_charge_amt ?? 0),
        extra_charge_note: v.extra_charge_note ? String(v.extra_charge_note) : null,
      };

      if (poNo) payload.po_no = poNo;

      const r: any = await createPo(payload);
      message.success(`สร้าง PO (DRAFT) แล้ว เลขที่ ${r.po_no ?? ""}`.trim(), 1.5);
      nav(`/purchase/po/${r.id}`, { replace: true });
    } catch (e: any) {
      message.error(e?.response?.data?.message || "สร้าง PO ไม่สำเร็จ", 2);
    } finally {
      setLoading(false);
    }
  }

  const productOptions = useMemo(
    () => products.map((p) => ({ value: p.id, label: `${p.code} - ${p.name}` })),
    [products],
  );

  const taxOptions = [
    { value: "EXCLUDE_VAT_7", label: "แยกภาษี 7%" },
    { value: "INCLUDE_VAT_7", label: "รวมภาษี 7%" },
    { value: "NO_VAT", label: "ไม่มีภาษี" },
  ];

  const vendorPeopleOptions = useMemo(() => {
    return vendorPeople
      .filter((p) => Number(p.id) > 0)
      .map((p) => ({
        value: Number(p.id),
        label: personLabel(p),
      }));
  }, [vendorPeople]);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <Title level={3} className="!mb-1">
            สร้าง PO
          </Title>
          <Text type="secondary">สร้างใบสั่งซื้อ (DRAFT) ก่อน แล้วค่อย Approve</Text>
        </div>

        <Space>
          <Button onClick={() => nav("/purchase/po")}>กลับรายการ</Button>
          <Button type="primary" loading={loading} onClick={submit}>
            บันทึก (DRAFT)
          </Button>
        </Space>
      </div>

      {/* Header Form */}
      <Card loading={loading}>
        <Form form={form} layout="vertical">
          <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
            <Form.Item label="รูปแบบเลขเอกสาร" className="md:col-span-2">
              <Space>
                <Switch
                  checked={autoNo}
                  onChange={(checked) => {
                    setAutoNo(checked);
                    if (checked) form.setFieldsValue({ po_no: "" });
                  }}
                  checkedChildren="AUTO"
                  unCheckedChildren="MANUAL"
                />
                <Text type="secondary">{autoNo ? "ปล่อยว่าง ระบบรันเลขให้" : "กรอกเลขเอง"}</Text>
              </Space>
            </Form.Item>

            <Form.Item
              name="po_no"
              label="เลขที่ PO"
              className="md:col-span-2"
              rules={autoNo ? [] : [{ required: true, message: "โหมด MANUAL ต้องกรอกเลขที่ PO" }]}
              extra={autoNo ? "โหมด AUTO: ระบบจะสร้างเลขให้เมื่อบันทึก" : undefined}
            >
              <Input placeholder={autoNo ? "AUTO" : "เช่น PO-2026-0001"} disabled={autoNo} />
            </Form.Item>

            <Form.Item
              name="issue_date"
              label="วันที่ออก"
              className="md:col-span-1"
              rules={[{ required: true, message: "เลือกวันที่" }]}
            >
              <DatePicker className="w-full" />
            </Form.Item>

            <Form.Item name="expected_date" label="วันที่คาดว่าจะรับเข้า" className="md:col-span-1">
              <DatePicker className="w-full" />
            </Form.Item>

            <Form.Item
              name="vendor_id"
              label="Vendor"
              className="md:col-span-2"
              rules={[{ required: true, message: "เลือก Vendor" }]}
            >
              <Select
                showSearch
                placeholder="เลือกผู้ขาย"
                options={vendors.map((v) => ({
                  value: v.id,
                  label: `${v.code} - ${v.name}`,
                }))}
              />
            </Form.Item>

            <Form.Item
              name="vendor_person_id"
              label="ผู้ติดต่อหลัก"
              className="md:col-span-2"
              rules={[{ required: true, message: "เลือกผู้ติดต่อหลัก" }]}
              extra="กรุณาเลือก Vendor ก่อน"
            >
              <Select
                loading={loadingPeople}
                disabled={!vendorId}
                placeholder={vendorId ? "เลือกผู้ติดต่อหลัก" : "เลือก Vendor ก่อน"}
                optionFilterProp="label"
                showSearch
                options={vendorPeopleOptions}
              />
            </Form.Item>

            <Form.Item
              name="warehouse_id"
              label="Warehouse"
              className="md:col-span-2"
              rules={[{ required: true, message: "เลือกคลัง" }]}
            >
              <Select
                showSearch
                placeholder="เลือกคลัง"
                options={warehouses.map((w) => ({
                  value: w.id,
                  label: `${w.code} - ${w.name}`,
                }))}
              />
            </Form.Item>
          </div>

          <Form.Item name="note" label="หมายเหตุ (ถ้ามี)">
            <Input.TextArea rows={2} />
          </Form.Item>

          {/* ✅ ซ่อนไว้ในฟอร์มเพื่อให้ validateFields เก็บค่าได้ (UI ไปอยู่ฝั่ง Summary) */}
          <div style={{ display: "none" }}>
            <Form.Item name="extra_charge_amt" initialValue={0}>
              <InputNumber />
            </Form.Item>
            <Form.Item name="extra_charge_note" initialValue={null}>
              <Input />
            </Form.Item>
          </div>
        </Form>
      </Card>

      {/* Items + Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: Items */}
        <Card className="lg:col-span-9" bodyStyle={{ paddingTop: 12 }}>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="font-semibold text-base">รายการสินค้า</div>
            <Button onClick={addLine}>เพิ่มสินค้า</Button>
          </div>

          <Divider className="!my-3" />

          <div className="space-y-3">
            {lines.map((l, idx) => {
              const r = calcLine(l);

              return (
                <div key={l.key} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-medium">รายการที่ {idx + 1}</div>
                    <Button danger onClick={() => removeLine(l.key)} disabled={lines.length <= 1}>
                      ลบ
                    </Button>
                  </div>

                  {/* Row 1 */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mt-3">
                    <div className="md:col-span-5">
                      <div className="text-xs text-gray-500 mb-1">สินค้า</div>
                      <Select
                        showSearch
                        placeholder="กรุณาเลือกก่อน"
                        value={l.product_id}
                        options={productOptions}
                        filterOption={(input, option) =>
                          String(option?.label ?? "").toLowerCase().includes(input.toLowerCase())
                        }
                        onChange={(val) => setLine(l.key, { product_id: Number(val) })}
                        style={{ width: "100%" }}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <div className="text-xs text-gray-500 mb-1">คงเหลือ</div>
                      <Input value={typeof l.onhand === "number" ? String(l.onhand) : "-"} disabled />
                    </div>

                    <div className="md:col-span-2">
                      <div className="text-xs text-gray-500 mb-1">จำนวน</div>
                      <InputNumber
                        min={1}
                        value={l.qty}
                        onChange={(val) => setLine(l.key, { qty: Number(val || 0) })}
                        style={{ width: "100%" }}
                      />
                    </div>

                    <div className="md:col-span-3">
                      <div className="text-xs text-gray-500 mb-1">ราคา/หน่วย (ต้นทุน)</div>
                      <InputNumber
                        min={0}
                        value={l.unit_cost}
                        onChange={(val) => setLine(l.key, { unit_cost: Number(val ?? 0) })}
                        style={{ width: "100%" }}
                      />
                    </div>
                  </div>

                  {/* Row 2 */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mt-3">
                    <div className="md:col-span-2">
                      <div className="text-xs text-gray-500 mb-1">ส่วนลด (%)</div>
                      <InputNumber
                        min={0}
                        max={100}
                        value={l.discount_pct}
                        onChange={(val) => setLine(l.key, { discount_pct: Number(val ?? 0) })}
                        style={{ width: "100%" }}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <div className="text-xs text-gray-500 mb-1">ส่วนลดบาท</div>
                      <InputNumber
                        min={0}
                        value={l.discount_amt}
                        onChange={(val) => setLine(l.key, { discount_amt: Number(val ?? 0) })}
                        style={{ width: "100%" }}
                      />
                    </div>

                    <div className="md:col-span-4">
                      <div className="text-xs text-gray-500 mb-1">ประเภทภาษี</div>
                      <Select
                        value={l.tax_type}
                        options={taxOptions}
                        onChange={(val) => setLine(l.key, { tax_type: val as TaxType })}
                        style={{ width: "100%" }}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <div className="text-xs text-gray-500 mb-1">ก่อนภาษี</div>
                      <Input value={r.beforeTax.toLocaleString()} disabled />
                    </div>

                    <div className="md:col-span-2">
                      <div className="text-xs text-gray-500 mb-1">มูลค่ารวม</div>
                      <Input value={r.total.toLocaleString()} disabled />
                    </div>
                  </div>

                  <div className="text-xs text-gray-400 mt-2">
                    * กรุณาเลือกสินค้า/จำนวน/ต้นทุน เพื่อคำนวณยอดรวม
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* RIGHT: Summary + Extra Charge */}
        <Card className="lg:col-span-3" title="สรุปข้อมูล">
          <div className="space-y-3">
            <div className="flex justify-between">
              <div className="text-gray-600">รวมจำนวน</div>
              <div className="font-medium">{summary.totalQty.toLocaleString()}</div>
            </div>

            <div className="flex justify-between">
              <div className="text-gray-600">รวมมูลค่าก่อนส่วนลด</div>
              <div className="font-medium">{summary.base.toLocaleString()}</div>
            </div>

            <div className="flex justify-between">
              <div className="text-gray-600">รวมส่วนลด</div>
              <div className="font-medium">{summary.discount.toLocaleString()}</div>
            </div>

            <Divider className="!my-2" />

            <div className="flex justify-between">
              <div className="text-gray-600">ยอดสุทธิสินค้า</div>
              <div className="font-medium">{summary.net.toLocaleString()}</div>
            </div>

            {/* ✅ ค่าใช้จ่ายเพิ่มเติมอยู่ท้าย Card นี้ */}
            <Divider className="!my-2" />
            <div>
              <div className="text-sm font-medium mb-2">ค่าใช้จ่ายเพิ่มเติม</div>

              <Form.Item name="extra_charge_amt" label="จำนวนเงิน" className="!mb-2">
                <InputNumber min={0} style={{ width: "100%" }} placeholder="0" />
              </Form.Item>

              <Form.Item name="extra_charge_note" label="รายละเอียด" className="!mb-0">
                <Input placeholder="เช่น ค่าขนส่ง / ค่าบริการ / อื่นๆ" />
              </Form.Item>
            </div>

            <Divider className="!my-2" />

            <div className="flex justify-between">
              <div className="text-gray-600">ยอดรวมสุทธิ</div>
              <div className="text-lg font-semibold">{summary.grandTotal.toLocaleString()}</div>
            </div>

            <div className="text-xs text-gray-500">
              * เลือกคลังเพื่อให้ระบบแสดงคงเหลือ (ถ้าคุณทำ API สต็อกคงเหลือ)
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
