// PoDetailPage.tsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Button,
  Card,
  Collapse,
  Descriptions,
  Divider,
  Input,
  InputNumber,
  Modal,
  Select,
  Space,
  Tag,
  Typography,
  message,
} from "antd";
import { approvePo, cancelPo, getPo, type PoDetail } from "./purchaseApi";
import { ReloadOutlined } from "@ant-design/icons";
import dayjs from "dayjs";

const { Title, Text } = Typography;

type TaxType = "EXCLUDE_VAT_7" | "INCLUDE_VAT_7" | "NO_VAT";

function statusTag(s?: string) {
  if (s === "APPROVED") return <Tag color="green">APPROVED</Tag>;
  if (s === "CANCELLED") return <Tag color="red">CANCELLED</Tag>;
  return <Tag color="gold">DRAFT</Tag>;
}

function daysLeft(expected_date?: string | null) {
  if (!expected_date) return null;
  const end = dayjs(expected_date);
  if (!end.isValid()) return null;
  return end.startOf("day").diff(dayjs().startOf("day"), "day");
}

function renderDaysLeftTag(expected_date?: string | null) {
  const d = daysLeft(expected_date ?? null);
  if (d === null) return "-";
  if (d < 0) return <Tag color="red">{`${d} วัน`}</Tag>;
  if (d === 0) return <Tag color="orange">วันนี้</Tag>;
  return <Tag color="blue">{`${d} วัน`}</Tag>;
}

function normalizeTaxType(v: any): TaxType {
  const s = String(v ?? "").trim().toUpperCase();
  if (s === "EXCLUDE_VAT_7" || s === "INCLUDE_VAT_7" || s === "NO_VAT") return s as TaxType;
  return "EXCLUDE_VAT_7";
}

/**
 * คำนวณบรรทัด (เหมือนฝั่ง Create)
 * - base = qty*unit_cost
 * - discount = min(base, discPct + discAmt)
 * - afterDiscount = base - discount
 * - beforeTax / vat / total ตาม tax_type
 */
function calcLine(it: any) {
  const qty = Number(it?.qty || 0);
  const unit = Number(it?.unit_cost || 0);
  const base = qty * unit;

  const dp = Number(it?.discount_pct ?? 0);
  const da = Number(it?.discount_amt ?? 0);

  const discByPct = base * (dp / 100);
  const discount = Math.min(base, discByPct + da);
  const afterDiscount = Math.max(0, base - discount);

  const taxType = normalizeTaxType(it?.tax_type);

  let beforeTax = afterDiscount;
  let vat = 0;
  let total = afterDiscount;

  if (taxType === "EXCLUDE_VAT_7") {
    beforeTax = afterDiscount;
    vat = beforeTax * 0.07;
    total = beforeTax + vat;
  } else if (taxType === "INCLUDE_VAT_7") {
    // afterDiscount เป็นยอดที่ "รวม VAT" แล้ว
    total = afterDiscount;
    beforeTax = (total * 100) / 107;
    vat = total - beforeTax;
  } else {
    // NO_VAT
    beforeTax = afterDiscount;
    vat = 0;
    total = beforeTax;
  }

  return { qty, unit, base, discount, afterDiscount, beforeTax, vat, total, taxType };
}

const taxOptions = [
  { value: "EXCLUDE_VAT_7", label: "แยกภาษี 7%" },
  { value: "INCLUDE_VAT_7", label: "รวมภาษี 7%" },
  { value: "NO_VAT", label: "ไม่มีภาษี" },
];

export default function PoDetailPage() {
  const nav = useNavigate();
  const { id } = useParams();
  const poId = Number(id);

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<PoDetail | null>(null);

  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [acting, setActing] = useState(false);

  // collapse keys
  const [openKeys, setOpenKeys] = useState<string[]>([]);
  const allKeys = useMemo(
    () => (data?.items ?? []).map((it: any, idx: number) => String(it?.id ?? idx)),
    [data?.items],
  );

  async function load() {
    try {
      setLoading(true);
      const r = await getPo(poId);
      setData(r);
      // default: เปิดรายการแรก (ถ้ามี)
      const keys = (r?.items ?? []).map((it: any, idx: number) => String(it?.id ?? idx));
      setOpenKeys(keys.length ? [keys[0]] : []);
    } catch (e: any) {
      message.error(e?.response?.data?.message || "โหลด PO ไม่สำเร็จ", 2);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!Number.isFinite(poId) || poId <= 0) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [poId]);

  const header: any = data?.header;
  const items = data?.items ?? [];

  const canApprove = header?.status === "DRAFT";
  const canCancel = header?.status === "DRAFT" || header?.status === "APPROVED";

  async function onApprove() {
    Modal.confirm({
      title: "Approve PO?",
      content: "เมื่ออนุมัติแล้ว PO จะล็อกเป็น APPROVED (ยังไม่เพิ่มสต็อก)",
      okText: "Approve",
      cancelText: "ยกเลิก",
      centered: true,
      async onOk() {
        try {
          setActing(true);
          await approvePo(poId);
          message.success("Approve สำเร็จ", 1.2);
          await load();
        } catch (e: any) {
          message.error(e?.response?.data?.message || "Approve ไม่สำเร็จ", 2);
        } finally {
          setActing(false);
        }
      },
    });
  }

  async function onCancel() {
    const reason = cancelReason.trim();
    if (reason.length < 5) {
      message.error("กรอกเหตุผลอย่างน้อย 5 ตัวอักษร", 2);
      return;
    }

    try {
      setActing(true);
      await cancelPo(poId, reason);
      message.success("ยกเลิก PO แล้ว", 1.2);
      setCancelOpen(false);
      setCancelReason("");
      await load();
    } catch (e: any) {
      message.error(e?.response?.data?.message || "ยกเลิกไม่สำเร็จ", 2);
    } finally {
      setActing(false);
    }
  }

  // ✅ ผู้ติดต่อหลัก: อ่านจาก snapshot "vendor_person_*" (ตาม backend purchase.service.js)
  // และยัง fallback ไปที่ vendor_contact_* / vendor_contact object เผื่อคุณมีของเก่าอยู่ด้วย
  const personName = [
    header?.vendor_person_prefix,
    header?.vendor_person_first_name,
    header?.vendor_person_last_name,
  ]
    .filter(Boolean)
    .join(" ")
    .trim();

  const nick = header?.vendor_person_nickname ? ` (${header.vendor_person_nickname})` : "";
  const pos = header?.vendor_person_position ? ` • ${header.vendor_person_position}` : "";
  const dept = header?.vendor_person_department ? ` • ${header.vendor_person_department}` : "";

  const phone = header?.vendor_person_phone ? `โทร ${header.vendor_person_phone}` : "";
  const email = header?.vendor_person_email ? `อีเมล ${header.vendor_person_email}` : "";

  const personLine1 = (personName ? `${personName}${nick}${pos}${dept}` : "").trim();
  const personLine2 = [phone, email].filter(Boolean).join(" • ");

  const vendorContactName =
    header?.vendor_contact_name ?? header?.vendor_contact?.name ?? header?.vendor_contact?.label ?? null;
  const vendorContactPhone =
    header?.vendor_contact_phone ?? header?.vendor_contact?.phone ?? header?.vendor_contact_value ?? null;
  const vendorContactEmail =
    header?.vendor_contact_email ?? header?.vendor_contact?.email ?? null;
  const vendorContactPosition =
    header?.vendor_contact_position ?? header?.vendor_contact?.position ?? null;

  const legacyLine1 = [
    vendorContactName,
    vendorContactPosition ? ` • ${vendorContactPosition}` : null,
  ]
    .filter(Boolean)
    .join("")
    .trim();

  const legacyLine2 = [
    vendorContactPhone ? `โทร ${vendorContactPhone}` : null,
    vendorContactEmail ? `อีเมล ${vendorContactEmail}` : null,
  ]
    .filter(Boolean)
    .join(" • ");

  const contactDisplay = (() => {
    // 1) ใช้ vendor_person_* ก่อน (ของจริงใน DB ตาม service)
    if (personLine1 || personLine2) {
      if (personLine1 && personLine2) return `${personLine1} — ${personLine2}`;
      return personLine1 || personLine2;
    }

    // 2) fallback ของเก่า vendor_contact_*
    if (legacyLine1 || legacyLine2) {
      if (legacyLine1 && legacyLine2) return `${legacyLine1} — ${legacyLine2}`;
      return legacyLine1 || legacyLine2;
    }

    // 3) fallback แบบ vendor_contact_label/value
    const contactLabel =
      header?.vendor_contact_label ??
      header?.vendor_contact?.label ??
      header?.vendor_contact?.name ??
      null;

    const contactValue =
      header?.vendor_contact_value ??
      header?.vendor_contact?.value ??
      header?.vendor_contact?.phone ??
      header?.vendor_contact?.email ??
      null;

    if (contactLabel && contactValue) return `${contactLabel}: ${contactValue}`;
    if (contactValue) return String(contactValue);

    return "-";
  })();

  // summary totals (เหมือนกล่องขวาในรูป)
  const totals = useMemo(() => {
    return items.reduce(
      (acc: any, it: any) => {
        const r = calcLine(it);
        acc.totalQty += Number(r.qty || 0);
        acc.beforeTax += Number(r.beforeTax || 0);
        acc.vat += Number(r.vat || 0);
        acc.total += Number(r.total || 0);
        return acc;
      },
      { totalQty: 0, beforeTax: 0, vat: 0, total: 0 },
    );
  }, [items]);

  const collapseItems = useMemo(() => {
    return items.map((it: any, idx: number) => {
      const key = String(it?.id ?? idx);
      const r = calcLine(it);

      const headerText = `รายการที่ ${idx + 1} — ${it.code} - ${it.name}  จำนวน ${r.qty} | รวม ${r.total.toLocaleString()}`;

      return {
        key,
        label: headerText,
        children: (
          <div className="space-y-3">
            {/* Row 1 */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              <div className="md:col-span-6">
                <div className="text-xs text-gray-500 mb-1">สินค้า</div>
                <Input value={`${it.code} - ${it.name}`} disabled />
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500 mb-1">จำนวน</div>
                <InputNumber value={Number(it.qty)} disabled style={{ width: "100%" }} />
              </div>

              <div className="md:col-span-4">
                <div className="text-xs text-gray-500 mb-1">ราคา/หน่วย (ต้นทุน)</div>
                <InputNumber value={Number(it.unit_cost)} disabled style={{ width: "100%" }} />
              </div>
            </div>

            {/* Row 2 */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              <div className="md:col-span-2">
                <div className="text-xs text-gray-500 mb-1">ส่วนลด (%)</div>
                <InputNumber value={Number(it.discount_pct ?? 0)} disabled style={{ width: "100%" }} />
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500 mb-1">ส่วนลดบาท</div>
                <InputNumber value={Number(it.discount_amt ?? 0)} disabled style={{ width: "100%" }} />
              </div>

              <div className="md:col-span-4">
                <div className="text-xs text-gray-500 mb-1">ประเภทภาษี</div>
                <Select value={r.taxType} options={taxOptions} disabled style={{ width: "100%" }} />
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500 mb-1">ก่อนภาษี</div>
                <Input value={r.beforeTax.toLocaleString()} disabled />
              </div>

              <div className="md:col-span-2">
                <div className="text-xs text-gray-500 mb-1">มูลค่ารวม</div>
                <Input value={r.total.toLocaleString()} disabled />
              </div>
            </div>

            {/* VAT line (ขวา) */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              <div className="md:col-span-10" />
              <div className="md:col-span-2">
                <div className="text-xs text-gray-500 mb-1">VAT</div>
                <Input value={r.vat.toLocaleString()} disabled />
              </div>
            </div>

            <div className="text-xs text-gray-400">
              * คำนวณจาก qty × unit_cost − ส่วนลด และภาษีตามประเภทภาษี
            </div>
          </div>
        ),
      };
    });
  }, [items]);

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <Title level={3} className="!mb-1">PO Detail</Title>
          <Text type="secondary">ดูรายละเอียด + Approve/Cancel</Text>
        </div>

        <Space>
          <Button onClick={() => nav("/purchase/po")}>กลับรายการ</Button>
          <Button type="primary" onClick={() => nav("/purchase/po/new")}>สร้างใหม่</Button>
        </Space>
      </div>

      <Card loading={loading}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="text-lg font-semibold">{header?.po_no || "-"}</div>
            {statusTag(header?.status)}
          </div>

          <Space>
            <Button icon={<ReloadOutlined />} onClick={load} loading={loading}>Refresh</Button>
            <Button type="primary" onClick={onApprove} disabled={!canApprove || acting}>Approve</Button>
            <Button danger onClick={() => setCancelOpen(true)} disabled={!canCancel || acting}>Cancel</Button>

            <Button
              onClick={() => nav(`/purchase/grn/new?poId=${header?.id}`)}
              disabled={!header?.id}
            >
              สร้าง GRN จาก PO
            </Button>
          </Space>
        </div>

        <Descriptions className="mt-4" column={2} bordered size="small">
          <Descriptions.Item label="Issue date">{header?.issue_date || "-"}</Descriptions.Item>
          <Descriptions.Item label="Expected date">{header?.expected_date || "-"}</Descriptions.Item>

          <Descriptions.Item label="เหลือ (วัน)">
            {renderDaysLeftTag(header?.expected_date ?? null)}
          </Descriptions.Item>
          <Descriptions.Item label="ผู้ติดต่อหลัก">
            {contactDisplay}
          </Descriptions.Item>

          <Descriptions.Item label="Warehouse">{header?.warehouse_name ?? header?.warehouse_id ?? "-"}</Descriptions.Item>
          <Descriptions.Item label="Vendor">{header?.vendor_name ?? header?.vendor_id ?? "-"}</Descriptions.Item>

          <Descriptions.Item label="Note" span={2}>
            {header?.note || "-"}
          </Descriptions.Item>

          <Descriptions.Item label="Cancel reason" span={2}>
            {header?.cancel_reason || "-"}
          </Descriptions.Item>
        </Descriptions>
      </Card>

      {/* ✅ รายการสินค้าแบบในรูป */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: items */}
        <Card className="lg:col-span-9" title="รายการสินค้า">
          <div className="flex items-center justify-end gap-2 flex-wrap">
            <Button onClick={() => setOpenKeys(allKeys)} disabled={!allKeys.length}>
              ขยายทั้งหมด
            </Button>
            <Button onClick={() => setOpenKeys([])} disabled={!allKeys.length}>
              พับทั้งหมด
            </Button>
          </div>

          <Divider className="!my-3" />

          <Collapse
            activeKey={openKeys}
            onChange={(keys) => setOpenKeys(Array.isArray(keys) ? (keys as string[]) : [String(keys)])}
            items={collapseItems as any}
          />
        </Card>

        {/* RIGHT: summary */}
        <Card className="lg:col-span-3" title="สรุปข้อมูล">
          <div className="space-y-3">
            <div className="flex justify-between">
              <div className="text-gray-600">รวมจำนวน</div>
              <div className="font-medium">{totals.totalQty.toLocaleString()}</div>
            </div>

            <div className="flex justify-between">
              <div className="text-gray-600">รวมก่อนภาษี</div>
              <div className="font-medium">{totals.beforeTax.toLocaleString()}</div>
            </div>

            <div className="flex justify-between">
              <div className="text-gray-600">ภาษีมูลค่าเพิ่ม</div>
              <div className="font-medium">{totals.vat.toLocaleString()}</div>
            </div>

            <Divider className="!my-2" />

            <div className="flex justify-between">
              <div className="text-gray-600">รวมมูลค่า</div>
              <div className="text-lg font-semibold">{totals.total.toLocaleString()}</div>
            </div>

            <div className="text-xs text-gray-500">
              * รวมจาก (qty×unit_cost − ส่วนลด) และภาษีตามประเภทภาษี
            </div>
          </div>
        </Card>
      </div>

      <Modal
        open={cancelOpen}
        title="Cancel PO"
        okText="ยืนยันยกเลิก"
        okButtonProps={{ danger: true, loading: acting }}
        onOk={onCancel}
        centered
        onCancel={() => {
          setCancelOpen(false);
          setCancelReason("");
        }}
      >
        <Input.TextArea
          rows={4}
          value={cancelReason}
          onChange={(e) => setCancelReason(e.target.value)}
          placeholder="เหตุผล (อย่างน้อย 5 ตัวอักษร)"
        />
      </Modal>
    </div>
  );
}
